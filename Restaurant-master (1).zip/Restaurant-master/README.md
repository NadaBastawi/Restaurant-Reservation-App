# Restaurant
Guided Project: Restaurant from “[App Development with Swift](https://itunes.apple.com/ru/book/app-development-with-swift/id1219117996)” by Apple Education.

![Categories Screenshot](https://github.com/dbystruev/Restaurant/blob/master/Restaurant/images/Categories.png?raw=true)
![Entrees Screenshot](https://github.com/dbystruev/Restaurant/blob/master/Restaurant/images/Entrees.png?raw=true)
![Meetballs Screenshot](https://github.com/dbystruev/Restaurant/blob/master/Restaurant/images/Meatballs.png?raw=true)
![Order Screenshot](https://github.com/dbystruev/Restaurant/blob/master/Restaurant/images/Order.png?raw=true)

Учебный проект «Ресторан» курса Apple «[Разработка приложений на языке Swift](https://itunes.apple.com/ru/book/app-development-with-swift/id1219117996)»
